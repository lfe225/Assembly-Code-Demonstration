# CSE202-Assembly-SU2022
Assembly: A programming exercise to write, compile, and link assembly code

# Learning Objectives
1) Write different functions in X86-64 ISA assembly code 
2) Compile assembly (.S) source files using the GNU AS(as) assembler
3) Write C program that uses functions compiled from assembly into object files
4) Link compiled assembly object files with the main C program
5) View the values in registers and the stack frame using gdb

# Instructions
Use the C program named prog2.c to call externally defined functions that you will write in assembly. You do NOT need (nor should you) edit the prog2.c code. In prog2.c, you will see eight  function prototypes that are defined in separate assembly source code files: abs.S, mult7div8.S, area.S, max.S, sort.S, reverse.S, sort.S, and product.S. They are named based on the operation they perform. For example, abs returns the absolute value of its argument and max returns the maximum value in a list of shorts.

Your task is to implement each function in X86-64 assembly. Because of this requirement, it is highly recommended you do your development work on the sunlab machines.

The abs function has already been implemented, so you have an example of what you are to do. Additionally, function shells have already been written in mult7div8.S, area.S, max.S, sort.S, reverse.S, sort.S, and product.S. Here's a listing of the purpose of the functions. The C code is provided as comments at the end of each .S file. 

- **abs**: raccepts one integer as a parameter and returns its absolute value
  
- **mult7div8**: accepts two parameters: a signed character and a pointer to an unsigned char. The function multiplies the signed character by 7 and divides the product by 8 using shift and add/sub operations only. If the multiplication  overflows, the unsigned character is set 1 and to 0 if no overflow occurs.
  
- **max**: accepts four short integers and returns the maximum value.
  
- **area**: accepts three integers a, b, and c, representing the sides of a triangle and returns the area of the triangle. The area of a triangle is sqrt(p*(p-a)*(p-b)*(p-c)), where p is (a+b+c)/2. area invokes a recursive function, defined in the same file area.S, to recursively determine the square root of an integer. The C code of the recursive sqrt is provided in area.S.

- **reverse**: accepts two parameters: a pointer to an array of strings and an unsigned for the size of the array. The function reverses the elements in the array.
  
- **sort**: accepts a pointer to an array of integers and sorts the array using the bubble sort C algorithm provided in the file sort.S.
  
- **sum**: accepts a pointer to the head of a linked list (struct ll defined in prog2.c) and returns the sum of the field value in the linked list nodes.
  
- **product**: accepts three pointers to float (vectors of float) and an unsigned integer for the size of the three vectors, and returns the product of the first vector by the second vector in the third vector. The equation below shows how the vector product is performed:
`[1.5 1.5 1.5] x [2.0 2.0 2.0] = [3.0 3.0 3.0]` 

Before you modify anything, you should test what you have downloaded. To do this, simply type "bash runTests.sh". This Bash script compiles the program and runs a suite of tests. It compares the output of your program with the reference output of the program. You do NOT need (nor should you) edit runTests.sh, makefile, tests.reference, or prog2.c.

In addition to submitting your code in the various assembly .S files, you need to upload a JPEG file. The JPEG you are to create while you are developing/debugging your code for the sort function. While running "gdb -tui --args ./prog2 sort 8 7 6 5 4 3 2 1", step into the sort function and type the gdb command "info registers" to display all the register values. Know that you can use the shortcut "i r" to do the same thing, and you can type "i r edi" to just print the value in the %edi register, for example. Save a screenshot of the output into a "registers.jpg" file and push this to GitHub. You don't have to use the arguments I listed, those are just examples.

# Recommended Approach
1) Leverage the textbook.
2) Work on this assignment a little every day.

# Important Notes
1) Add comments to your code; it will help you and the graders!
2) Do NOT modify the files prog2.c, runTests.sh, makefile, tests.reference; only modify the .S files.
3) Push your code often!!! This will give you a backup, enable you to retrieve earlier versions, and demonstrate you actually wrote the code over time. If you only perform one push of your final code, your submission will be THOROUGHLY evaluated to ensure it is original. 
4) Refer to the Grading Rubric to maximize your score.
5) To submit your code for grading, simply perform a "git push"; which will upload your changes to GitHub Classroom and run the auto-grader. You may continue to push changes until you are informed "All tests passed".
6) Post any questions on Piazza.
